export const addRecipe = (recipe) => ({
  type: 'ADD_RECIPE',
  payload: recipe,
});
